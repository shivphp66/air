jQuery(".register").validate({
	rules:{
		first_name:{
			required:true,
			minlength:2
		},
       last_name:{
			required:true,
			minlength:2
		},
		email:{
			    required:true,
			    email:true			
			},
		
		userName:{
			required:true,
			minlength:6,
			maxlength:10
		},
		password:{
			    required:true,
				minlength:6,
			    maxlength:10
		},
		
		cpassword : {
			         required:true,
					 minlength : 6,
					 maxlength:10,
					 equalTo : "#password"
				},
		
	   },
	messages:{
	      first_name:{
			required:"First Name is Required",
			minlength:"First Name Minimum 5 char"
		},
		last_name:{
			required:"Last Name is Required",
			minlength:"Last Name Minimum 5 char"
		},
		email:{
			required:"Email is required",
			emailId:"Enter valid Email"
		},
		userName:{
			required:"User Name is Required",
			minlength:"User Name shoud be 6-10 Char",
			maxlength:"User Name shoud be 6-10 Char"
		},
		password:{
			   required:"Password is Required",
			   minlength:"Password shoud be 6-10 Char",
			   maxlength:"Password shoud be 6-10 Char"
		},
		cpassword:{
			   required:"CPassword is Required",
			   minlength:"Password shoud be 6-10 Char",
			   maxlength:"Password shoud be 6-10 Char"
		},
		
	},
	
	/* submitHandler:function(form){
	 form.submit();		
	} */
	
});

$('.mybuttan').click(function(){
    console.log($('.register').valid());
});