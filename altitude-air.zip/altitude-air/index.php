<?php $BASE_URL = (empty($_SERVER['HTTPS']) ? 'http' : 'https')."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">    
    <title>Register</title>
	<style>
	 .error{color:red;}
	</style>
    <link rel="stylesheet" href="style.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
 <section class="h-100 bg-dark">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col">
        <div class="card card-registration my-4">
          <div class="row g-0">
            <div class="col-xl-6 d-none d-xl-block">
            <img src="img/attitute.png" alt="Sample photo" class="img-fluid" style="border-top-left-radius: .25rem; border-bottom-left-radius: .25rem; height: 500px;" />
            <div class="btext">
			   <h2 style="text-align: center; color: #ffff; padding-top: 20px;">Altitude Air</h2>
			   <p style="text-align: center; color: #ffff;">Altitude Air Pvt. Ltd is a helicopter airline based at Tribhuvan International Airport in Kathmandu, Nepal, operating chartered helicopter services.</p>
			</div>
			</div>
			
            <div class="col-xl-6">
			
              <div class="card-body p-md-5 text-black">
			   <div id="sing">SING IN</div>
                 <h3 style="margin-top: 80px;">Explore & Experience</h3>
				 <p class="">get into your most comfortable journey yes. All the way up</p>
				  <h4 style="color:green;" class="success-message"></h4>
				  <h4 style="color:red;" class="error-message"></h4>	
				 <form method="post" name="register" class="register" id="register">
                 <div class="row">
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">					 
                      <input type="text" id="first_name" name="first_name" class="form-control form-control-lg" placeholder="First name"/>
                    </div>
                  </div>
                  <div class="col-md-6 mb-4">
                    <div class="form-outline">					
                      <input type="text" id="last_name" name="last_name" class="form-control form-control-lg" placeholder="Last name"/>
                     </div>
                  </div>
                </div>
				 <div class="form-outline mb-4">				
                  <input type="text" id="email" name="email" class="form-control form-control-lg" placeholder="Email"/>                 
                </div>

                <div class="form-outline mb-4">				 
                  <input type="text" id="userName" name="userName" class="form-control form-control-lg" placeholder="UserName"/>                 
                </div>
				
				<div class="form-outline mb-4">				 
                  <input type="text" id="password" name="password" class="form-control form-control-lg" placeholder="Password"/>                 
                </div>
				
				<div class="form-outline mb-4">				
                  <input type="password" id="cpassword" name="cpassword" class="form-control form-control-lg"  placeholder="confirm Password"/>                 
                  <p id="cpass_error"></p>
				</div>

                <div class="d-flex justify-content-end pt-3">                  
                  <input type="submit" name="submit" value="Get Start" class="btn btn-primary mybuttan" style="width: 300px; margin-right: 80px;">
                </div>
               </form>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.5/jquery.validate.min.js" integrity="sha512-rstIgDs0xPgmG6RX1Aba4KV5cWJbAMcvRCVmglpam9SoHZiUCyQVDdH2LPlxoHtrv17XWblE/V/PP+Tr04hbtA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	  <script src="js/formValidation.js"></script>
	 <script>
	  $(document).ready(function(){	 
		  
		  function message(message,statu){
			 if(statu==true){
				$(".register").trigger("reset");
				$('.success-message').html(message).slideDown(); 
				$('.error-message').slideUp();
                setTimeout(function(){
				 $('.success-message').slideUp(); 				  
			  },8000);
				 
			 }
			 else if(statu==false){
				$('.error-message').html(message).slideDown(); 
				$('.success-message').slideUp();
                setTimeout(function(){
				 $('.error-message').slideUp(); 				  
			  },4000);			
			 } 
		  }
		  
   /*****************************form data sirializetion************************************/		  
		  function jsonData(targerForm){
			    var arr = $(targerForm).serializeArray();              		 
			     var obj = {};
				 for(var a=0; a < arr.length; a++){
					 if(arr[a].value == ""){						 
						 return false;						 
					 }
					obj[arr[a].name]= arr[a].value; 
				 }			 
				 var jsonStrin = JSON.stringify(obj);
				 return jsonStrin;
				 
		        }
		  /********************************pass the data to Api**********************************/
		  
		    $('.mybuttan').on('click',function(e){
		       e.preventDefault();
			    var jsonObject = jsonData('.register');
				console.log(jsonObject);
			    
                if(jsonObject==false){
					message('All Field is required',false);
				}
               else{
				  $.ajax({
				       url : '<?=$BASE_URL; ?>Api/Api_register.php',
					   type : "POST",					
					   data :jsonObject,
					   success: function(data){
						 console.log(data);
						 if(data.status == true){
							   message('Register Successfull',data.status);
						 } 
						 else{
							 message(data.message,data.status);
						 }
					   }
				 
		           }); 
			     }				
		       });
		 	  
	       });
	 
</script>
</body>
</html>