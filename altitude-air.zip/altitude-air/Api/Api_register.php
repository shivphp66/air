<?php 
      header("Access-Control-Allow-Origin: *");
	  header("Access-Control-Allow-Headers: access");
	  header("Access-Control-Allow-Methods: POST");
	  header("Content-Type: application/json; charset=UTF-8");
	  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	
   include 'dbconfig.php';
   class ApiClass extends DB{  
	   
	    public function Register($param=array()){
		
		if($param['password'] !=$param['cpassword']){
		  return $error = 'Password And Cpassword Not Match';			
		}
		
		else{     		
	    
	    $check = $this->checkUserExist($param['userName']);
        $checkEmp = $check->num_rows;
        if($checkEmp >0){
		    return $error = 'This UserName Already Existed';			
		}
		else{
            //array_pop($param);			
			$field = implode(',', array_keys($param));
			$value = implode("','", array_values($param));
			
			//$sql = "INSERT INTO tb_register ($field) values('$value')"; 
			
			$sql = "INSERT INTO tb_register(first_name,last_name,email,userName,password) 
			values('".$param['first_name']."','".$param['last_name']."','".$param['email']."','".$param['userName']."','".$param['password']."')"; 
			//echo $sql; die; 
		   $query = $this->mysqli->query($sql);	   
		   return 1;
		}

      }		
	}
	
	public function checkUserExist($userName){
		$sql = "SELECT userName FROM tb_register where userName='".$userName."' ";
		$query = $this->mysqli->query($sql);
		return $query;
	   }
		
      }

	$Obj = new ApiClass();	
     
	 $data = json_decode(file_get_contents("php://input"));
	  if(($_SERVER["REQUEST_METHOD"]) == "POST" AND ($_SERVER["REQUEST_METHOD"] !='')){
		 
		 $param = [
			   'first_name'  => $data->first_name,
			   'last_name'   => $data->last_name,
			   'email'       => $data->email,
			   'userName'    => trim($data->userName),
			   'password'    => md5(trim($data->password)),
			   'cpassword'   => md5(trim($data->cpassword)),
			   
       ];
		 
		 
		 $result = $Obj->Register($param);
		 if($result==1){
				  $response = array("code"=>1,"status"=>true,"message"=>$result); 
		 }
		 else{
			  $response = array("code"=>0,"status"=>false,"message"=>$result);		
			 }
	}
		 
    echo json_encode($response);
	   
  