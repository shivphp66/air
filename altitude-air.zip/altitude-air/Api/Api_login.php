<?php 
      header("Access-Control-Allow-Origin: *");
	  header("Access-Control-Allow-Headers: access");
	  header("Access-Control-Allow-Methods: POST");
	  header("Content-Type: application/json; charset=UTF-8");
	  header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	
   include '../config/dbconfig.php';
   class ApiClass extends DB{  
	   
	    public function employee_login($userName,$password){				
		   $sql = "SELECT id,userName,password,user_roll FROM employee where userName='".$userName."' and password='".$password."' ";
			//echo $sql; die;
			$query = $this->mysqli->query($sql);
			 $recodeCheck =$query->num_rows;
			 if($recodeCheck >0){
				 $row = $query->fetch_array();			  
				  $_SESSION['uid'] = $row['id'];
				  $_SESSION['user_name'] = $row['userName'];
				  $_SESSION['user_roll'] = $row['user_roll'];				
				 //header('location:dashbord.php');
				 return 1;
			    }else{ 
			          return $error = 'Username or Password not Match';
			}
		  } 
        }

	  $Obj = new ApiClass();
	
     
	 $data = json_decode(file_get_contents("php://input"));
	  if(($_SERVER["REQUEST_METHOD"]) == "POST" AND ($_SERVER["REQUEST_METHOD"] !='')){		
		 $userName = trim($data->userName); 
		 $password = md5(trim($data->password));
		 $result = $Obj->employee_login($userName,$password);
		 if($result==1){
				  $response = array("code"=>1,"status"=>true,"message"=>$result); 
		 }
		 else{
			  $response = array("code"=>0,"status"=>false,"message"=>$result);		
			 }
	}
		 
    echo json_encode($response);
	   
  