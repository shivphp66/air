<?php
Class DB{
	
	private $hostName = "localhost";
	private $username = "root";
	private $password = "";
	private $dbName = "altitude_air";	
    public $mysqli = "";
	
	public function __construct(){	
	   $this->mysqli = new mysqli($this->hostName,$this->username,$this->password,$this->dbName);    
	if($this->mysqli->connect_error){
		 return $this->mysqli->connect_error;		
	}else{
       return true;		
	 }	
    }
 

}




?>